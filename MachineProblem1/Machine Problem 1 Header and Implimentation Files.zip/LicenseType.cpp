#include <iostream>
#include "Licensetype.hpp"


string LicenseType::descriptions[9] = {"All types of motorcycles", "Construction vehicle", "Agricultural vehicle", "Private passenger vehicle" , "Commercial passenger vehicle", "Minibus", "Buses", "Trailer and semi-trailer", "Vehicle eqiupped for disabled"};


void LicenseType::outputData() 
{ 
	cout << type << " -- " << description << "\n";
};