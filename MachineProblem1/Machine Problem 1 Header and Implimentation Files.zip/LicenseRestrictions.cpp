#include <iostream>
#include "LicenseRestrictions.hpp"

string LicenseRestrictions::restrictions[7] = { "None", "Glasses", "Earphones", "Automatic", "Disabled", "Lenses", "Deaf" };

void LicenseRestrictions::outputData() 
{
	cout << number << " -- " << restriction << "\n";
};