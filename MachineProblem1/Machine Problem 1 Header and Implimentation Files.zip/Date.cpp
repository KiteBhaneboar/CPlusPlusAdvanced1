#include <iostream>
#include "Date.hpp"

using namespace std;

void Date::outputData()
{ 
	cout << day << "/" << month << "/" << year << endl; 

}