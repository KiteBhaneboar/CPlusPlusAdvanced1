#include <iostream>
#include "Name.hpp"

using namespace std;

void Name::outputData() 
{
	cout << first << " " << father << " " << family << endl;
}
